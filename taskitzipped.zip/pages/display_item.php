<div class="col-xs-12 individual_item_container">
    <div class="col-xs-12 itme_title">
        <p>Do Laundry</p>
    </div>
    <div class="col-xs-12 item_date">
        <p>12/17/2015</p>
    </div>
    <div class="col-xs-12 item_details">
        <p>These are the details regarding the laundry. We need to do three loads and separate the darks and lights. Also dont forget to wash the sheets.</p>
    </div>
    <div class="col-xs-6 item_time_stamp">
        <p>time stamp</p>
    </div>
    <div class="col-xs-6 item_completed">
        <p>Completed</p>
    </div>
</div>