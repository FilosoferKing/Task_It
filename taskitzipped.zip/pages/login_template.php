<header class="col-xs-12 container logged_out row">
    <div class="col-xs-12 col-sm-4 col-sm-push-4 header_title">
        <h1>TO DO LIST</h1>
    </div>
    <div class="col-xs-12 col-sm-4 col-sm-pull-4 input row">
        <div class="col-xs-12 col-sm-4 input">
            <input class="col-xs-12" type="text" name="username" placeholder="Username">
        </div>
        <div class="col-xs-12 col-sm-4 input">
            <input class="col-xs-12" type="text" name="password" placeholder="Password">
        </div>
        <button class="col-xs-12 button col-sm-4" type="button" name="login">
            LOGIN
        </button>
    </div>
</header>